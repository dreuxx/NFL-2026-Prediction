"""
FLOFO (Fast Leave One Feature Out) Importance Analysis
Para ejecutar en Kaggle Notebooks

Este script usa modelos ya entrenados para evaluar feature importance
mediante permutaciones rápidas (sin re-entrenar).

Uso:
    python flofo_analysis.py --model_path ./output/default/seed_42/model_fold1.pt \
                             --scaler_path ./output/default/seed_42/scaler_fold1.pkl \
                             --data_path /kaggle/input/nfl-big-data-bowl-2026-prediction/
"""

import numpy as np
import pandas as pd
import torch
import joblib
from pathlib import Path
from tqdm.auto import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
from typing import List, Dict

# Import your model components
import sys
sys.path.append('/content')  # Adjust if needed

from src.config import Config
from src.model import STTransformer
from src.utils import load_input_output, prepare_targets_stt
from src.preprocess import prepare_sequences_with_advanced_features
from src.validation import compute_val_rmse_stt


class FLOFOImportance:
    """
    Fast LOFO using permutation importance with grouped permutations.
    """

    def __init__(self, model, scaler, feature_names, device='cuda'):
        self.model = model
        self.scaler = scaler
        self.feature_names = feature_names
        self.device = device
        self.model.eval()

    def permute_feature(self, X, feature_idx, n_permutations=5):
        """
        Permute a single feature across samples.
        Uses grouped permutations to avoid unrealistic values.
        """
        importances = []

        for _ in range(n_permutations):
            X_permuted = X.copy()
            # Permute within the batch (simple version)
            perm_idx = np.random.permutation(len(X))
            X_permuted[:, :, feature_idx] = X[perm_idx, :, feature_idx]
            importances.append(X_permuted)

        return importances

    def compute_importance(self, X_val, y_val_dx, y_val_dy, n_permutations=10):
        """
        Compute FLOFO importance for all features.
        """
        # Baseline performance
        X_val_scaled = [self.scaler.transform(x) for x in X_val]
        baseline_rmse = compute_val_rmse_stt(
            self.model,
            X_val_scaled,
            y_val_dx,
            y_val_dy,
            Config.MAX_FUTURE_HORIZON,
            self.device
        )

        print(f"Baseline RMSE: {baseline_rmse:.4f} yards")

        # Feature importances
        importances = []

        for feat_idx in tqdm(range(len(self.feature_names)), desc="Computing FLOFO"):
            feat_name = self.feature_names[feat_idx]

            # Permute this feature
            permuted_rmses = []

            for perm_i in range(n_permutations):
                # Create permuted version
                X_val_perm = []
                perm_indices = np.random.permutation(len(X_val))

                for i, x in enumerate(X_val):
                    x_perm = x.copy()
                    # Permute the feature from a random other sample
                    donor_idx = perm_indices[i]
                    x_perm[:, feat_idx] = X_val[donor_idx][:, feat_idx]
                    X_val_perm.append(x_perm)

                # Scale and evaluate
                X_perm_scaled = [self.scaler.transform(x) for x in X_val_perm]
                rmse_perm = compute_val_rmse_stt(
                    self.model,
                    X_perm_scaled,
                    y_val_dx,
                    y_val_dy,
                    Config.MAX_FUTURE_HORIZON,
                    self.device
                )
                permuted_rmses.append(rmse_perm)

            # Importance = how much worse the model gets when feature is permuted
            mean_rmse_perm = np.mean(permuted_rmses)
            std_rmse_perm = np.std(permuted_rmses)
            importance = mean_rmse_perm - baseline_rmse  # Positive = feature is important

            importances.append({
                'feature': feat_name,
                'importance_mean': importance,
                'importance_std': std_rmse_perm,
                'baseline_rmse': baseline_rmse,
                'permuted_rmse_mean': mean_rmse_perm,
            })

        return pd.DataFrame(importances).sort_values('importance_mean', ascending=False)


def plot_importance(importance_df, top_n=30, figsize=(10, 12)):
    """Plot feature importance with error bars."""
    plt.figure(figsize=figsize)

    # Top N most important
    top_df = importance_df.head(top_n)

    # Create barplot
    y_pos = np.arange(len(top_df))
    plt.barh(y_pos, top_df['importance_mean'],
             xerr=top_df['importance_std'],
             capsize=3,
             color=['green' if x > 0 else 'red' for x in top_df['importance_mean']])

    plt.yticks(y_pos, top_df['feature'])
    plt.xlabel('FLOFO Importance (yards)\n← Harmful | Helpful →')
    plt.title(f'Top {top_n} Features by FLOFO Importance')
    plt.axvline(x=0, color='black', linestyle='--', linewidth=1)
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()

    return plt.gcf()


def main():
    """Main execution for Kaggle."""

    # Paths - Updated to user's Kaggle dataset
    MODEL_DIR = Path('output/20251108_071543/seed_42')
    DATA_PATH = Path('/kaggle/input/nfl-big-data-bowl-2026-prediction/')

    print("=" * 70)
    print("FLOFO Importance Analysis for NFL Tracking")
    print("Using ALL 5 FOLDS for robust estimates")
    print("=" * 70)

    # 1. Load all 5 models and scalers
    print("\n[1/5] Loading all 5 fold models and scalers...")
    models = []
    scalers = []

    for fold in range(1, 6):
        model_path = MODEL_DIR / f"model_fold{fold}.pt"
        scaler_path = MODEL_DIR / f"scaler_fold{fold}.pkl"

        # Load scaler
        # Changed from pickle.load to joblib.load
        scaler = joblib.load(scaler_path)
        scalers.append(scaler)

        # Load model
        input_dim = scaler.n_features_in_
        model = STTransformer(input_dim=input_dim)
        model.load_state_dict(torch.load(model_path, map_location=Config.DEVICE))
        model.to(Config.DEVICE)
        model.eval()
        models.append(model)

    print(f"✓ Loaded {len(models)} models: {input_dim} features each")

    # 2. Load validation data
    print("\n[2/5] Loading validation data...")
    train_input, train_output = load_input_output()

    # Use FULL dataset for robust importance estimates
    Config.DEBUG = False  # IMPORTANT: Use all data, not subset!
    # Config.DEBUG_SIZE not used when DEBUG=False

    seqs, tdx, tdy, tfids, seq_meta, feat_cols = prepare_sequences_with_advanced_features(
        train_input,
        output_df=train_output,
        feature_groups=Config.FEATURE_GROUPS,
    )

    print(f"✓ Loaded: {len(seqs)} samples, {len(feat_cols)} features")

    # 3. Split data into 5 folds (matching training splits)
    print("\n[3/5] Splitting data into 5 folds...")
    from sklearn.model_selection import GroupKFold

    groups = np.array([f"{m['game_id']}_{m['play_id']}" for m in seq_meta])
    _, groups_idx = np.unique(groups, return_inverse=True)

    gkf = GroupKFold(n_splits=5)
    fold_splits = list(gkf.split(seqs, groups=groups_idx))

    # 4. Run FLOFO on each fold's validation set
    print("\n[4/5] Running FLOFO Analysis on all 5 folds...")
    all_fold_importances = []

    for fold_idx, (train_idx, val_idx) in enumerate(fold_splits, 1):
        print(f"\n  Fold {fold_idx}/5...")

        # Get fold's validation data
        X_val = [seqs[i] for i in val_idx]
        y_val_dx = [tdx[i] for i in val_idx]
        y_val_dy = [tdy[i] for i in val_idx]

        # Use corresponding model and scaler
        model = models[fold_idx - 1]
        scaler = scalers[fold_idx - 1]

        # Run FLOFO
        flofo = FLOFOImportance(model, scaler, feat_cols, device=Config.DEVICE)
        fold_importance_df = flofo.compute_importance(X_val, y_val_dx, y_val_dy, n_permutations=10)

        # Add fold identifier
        fold_importance_df['fold'] = fold_idx
        all_fold_importances.append(fold_importance_df)

    # 5. Aggregate results across folds
    print("\n[5/5] Aggregating results across all folds...")

    # Combine all folds
    combined_df = pd.concat(all_fold_importances, ignore_index=True)

    # Aggregate by feature
    importance_summary = combined_df.groupby('feature').agg({
        'importance_mean': ['mean', 'std'],
        'baseline_rmse': 'mean',
        'permuted_rmse_mean': 'mean',
    }).reset_index()

    # Flatten column names
    importance_summary.columns = ['feature', 'importance_mean', 'importance_std',
                                   'baseline_rmse', 'permuted_rmse_mean']

    # Sort by importance
    importance_summary = importance_summary.sort_values('importance_mean', ascending=False)

    # Save results
    print("\nSaving results...")
    importance_summary.to_csv('flofo_importance_5folds.csv', index=False)
    combined_df.to_csv('flofo_importance_per_fold.csv', index=False)
    print("✓ Saved to flofo_importance_5folds.csv (aggregated)")
    print("✓ Saved to flofo_importance_per_fold.csv (detailed)")

    # Plot
    print("\nCreating visualizations...")
    fig = plot_importance(importance_summary, top_n=30)
    fig.savefig('flofo_importance_plot.png', dpi=150, bbox_inches='tight')
    print("✓ Saved to flofo_importance_plot.png")

    # Print summary
    print("\n" + "=" * 70)
    print("FLOFO IMPORTANCE SUMMARY (Averaged across 5 folds)")
    print("=" * 70)
    print("\nTop 10 Most Important Features:")
    print(importance_summary[['feature', 'importance_mean', 'importance_std']].head(10).to_string(index=False))

    print("\n\nTop 10 Most Harmful Features (negative importance):")
    harmful = importance_summary[importance_summary['importance_mean'] < 0].head(10)
    if len(harmful) > 0:
        print(harmful[['feature', 'importance_mean', 'importance_std']].to_string(index=False))
    else:
        print("No harmful features detected!")

    print("\n" + "=" * 70)
    print("Analysis complete!")
    print(f"Mean baseline RMSE across folds: {importance_summary['baseline_rmse'].iloc[0]:.4f} yards")
    print("=" * 70)


if __name__ == "__main__":
    main()
