# =============================================================================
# Evaluation API Server Setup
# =============================================================================
# New imports for evaluation API
import polars as pl
from src.utils import load_saved_ensemble_stt, invert_to_original_direction
from src.preprocess import prepare_sequences_with_advanced_features
from src.model import STTransformer
from src.predict import predict_sst

# Global variables to store models (loaded once on first predict call)
_models_loaded = False
_models = None
_scalers = None
_meta = None
_feature_cols = None


def load_models_once():
    """Load models on first predict call (no 5-minute time limit)"""
    global _models_loaded, _models, _scalers, _meta, _feature_cols

    if _models_loaded:
        return

    print("[SERVER] Loading models for first time...")
    # Use Config.TIME_TAG which is set in cell 6, or default to the directory name
    models_dir = Path("/kaggle/input/nfl2026")
    # Try to find the directory with models (should be named with TIME_TAG format)
    if Config.TIME_TAG and Config.TIME_TAG != "default":
        models_path = models_dir / Config.TIME_TAG
    else:
        # Fallback: look for any subdirectory or use the dataset root
        models_path = models_dir
        # Try to find the first subdirectory that contains meta.json
        if models_path.exists():
            for subdir in models_path.iterdir():
                if subdir.is_dir() and (subdir / "meta.json").exists():
                    models_path = subdir
                    break
    
    _models, _scalers, _meta = load_saved_ensemble_stt(models_path, STTransformer)
    _feature_cols = _meta["feature_cols"]

    _models_loaded = True
    print(f"[SERVER] Loaded {len(_models)} models successfully from {models_path}")


def predict(
    test: pl.DataFrame, test_input: pl.DataFrame
) -> pl.DataFrame | pd.DataFrame:
    """
    Inference function: process each batch of data

    Args:
        test: Frames to predict (contains game_id, play_id, nfl_id, frame_id, etc.)
        test_input: Available input data (historical frames)

    Returns:
        DataFrame with x, y coordinates
    """
    global _models, _scalers, _meta, _feature_cols

    # First call: load models (no time limit)
    if not _models_loaded:
        load_models_once()

    # Convert to pandas (our code is pandas-based)
    test_pd = test.to_pandas()
    test_input_pd = test_input.to_pandas()

    cfg = Config()
    saved_groups = _meta.get("feature_groups", cfg.FEATURE_GROUPS)

    # Build sequences
    test_seqs, test_meta, feat_cols_t = prepare_sequences_with_advanced_features(
        test_input_pd,
        test_pd,
        feature_groups=saved_groups,
    )

    idx_x = feat_cols_t.index("x")
    idx_y = feat_cols_t.index("y")

    X_test_raw = list(test_seqs)
    x_last_uni = np.array([s[-1, idx_x] for s in X_test_raw], dtype=np.float32)
    y_last_uni = np.array([s[-1, idx_y] for s in X_test_raw], dtype=np.float32)

    # Ensemble predictions with selective TTA
    # TTA only applied to best seed (seed 42) for efficiency
    all_preds_dx, all_preds_dy = [], []
    best_seed = 42  # Best performing seed gets TTA
    
    for idx, (m, sc) in enumerate(zip(_models, _scalers)):
        # Determine if this model is from best seed
        # Models are loaded in order: seed1_fold1-5, seed2_fold1-5, etc.
        # We need to check metadata to know which seed this model belongs to
        
        # For now, assume first N_FOLDS models are from seed 42
        # (works if SEEDS=[42] or SEEDS=[42, ...])
        apply_tta = idx < Config.N_FOLDS  # First 5 models (seed 42)
        
        dx_pred, dy_pred = predict_sst(
            m,
            sc,
            X_test_raw,
            cfg.DEVICE,
            use_tta=apply_tta,  # TTA only for seed 42 models
            tta_weight=cfg.TTA_WEIGHT if apply_tta else 0.0,
        )
        all_preds_dx.append(dx_pred)
        all_preds_dy.append(dy_pred)

    ens_dx = np.mean(all_preds_dx, axis=0)
    ens_dy = np.mean(all_preds_dy, axis=0)

    H = ens_dx.shape[1]

    # Build predictions
    rows = []
    tt_idx = test_pd.set_index(["game_id", "play_id", "nfl_id"]).sort_index()

    for i, meta_row in enumerate(test_meta):
        gid = meta_row["game_id"]
        pid = meta_row["play_id"]
        nid = meta_row["nfl_id"]
        play_dir = meta_row["play_direction"]

        try:
            fids = tt_idx.loc[(gid, pid, nid), "frame_id"]
            if isinstance(fids, pd.Series):
                fids = fids.sort_values().tolist()
            else:
                fids = [int(fids)]
        except KeyError:
            continue

        for t, fid in enumerate(fids):
            tt = min(t, H - 1)
            x_uni = np.clip(x_last_uni[i] + ens_dx[i, tt], 0, Config.FIELD_X_MAX)
            y_uni = np.clip(y_last_uni[i] + ens_dy[i, tt], 0, Config.FIELD_Y_MAX)
            x_uni, y_uni = invert_to_original_direction(
                x_uni, y_uni, play_dir == "right"
            )
            rows.append({"x": x_uni, "y": y_uni})

    predictions = pl.DataFrame(rows)

    assert len(predictions) == len(test)
    return predictions


if Config.SUBMIT:
    import kaggle_evaluation.nfl_inference_server  # type: ignore

    # Initialize inference server
    inference_server = kaggle_evaluation.nfl_inference_server.NFLInferenceServer(
        predict
    )

    # Start server in competition environment
    if os.getenv("KAGGLE_IS_COMPETITION_RERUN"):
        print("[SERVER] Starting inference server...")
        inference_server.serve()
    else:
        print("[SERVER] Running local gateway for testing...")
        inference_server.run_local_gateway(
            ("/kaggle/input/nfl-big-data-bowl-2026-prediction/",)
        )