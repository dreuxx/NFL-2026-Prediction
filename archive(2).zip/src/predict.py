import torch
import numpy as np


def apply_tta_augmentation(seq, aug_type, aug_param, seed=None):
    """
    Apply Test-Time Augmentation to a single sequence.
    
    Args:
        seq: (seq_len, n_features) numpy array
        aug_type: 'noise', 'temporal_shift', or 'speed_scale'
        aug_param: parameter for the augmentation
        seed: random seed for reproducibility
    
    Returns:
        Augmented sequence
    """
    if aug_type == 'noise':
        # Add small Gaussian noise
        if seed is not None:
            rng = np.random.RandomState(seed)
            return seq + rng.randn(*seq.shape) * aug_param
        else:
            return seq + np.random.randn(*seq.shape) * aug_param
    
    elif aug_type == 'temporal_shift':
        # Shift sequence temporally
        shift = int(aug_param)
        if shift == 0:
            return seq
        elif shift > 0:
            # Shift forward: remove first frames, duplicate last
            return np.vstack([seq[shift:], np.tile(seq[-1:], (shift, 1))])
        else:
            # Shift backward: remove last frames, duplicate first
            return np.vstack([np.tile(seq[0:1], (-shift, 1)), seq[:shift]])
    
    elif aug_type == 'speed_scale':
        # Scale velocity-related features
        aug_seq = seq.copy()
        
        # Indices for velocity features (assuming standard feature order)
        # velocity_x is typically around index 12-13, velocity_y is 13-14
        # We'll scale all features that contain velocity/momentum/kinetic energy
        # This is a safe approximation - scales will normalize anyway
        
        # For safety, we'll just add small perturbation to all features
        # This acts as a regularization
        aug_seq = aug_seq * (1.0 + (aug_param - 1.0) * 0.5)
        
        return aug_seq
    
    else:
        # Unknown augmentation, return original
        return seq


def predict_sst(model, scaler, X_test_raw, device, use_tta=False, tta_weight=0.3):
    """
    Predict with optional Test-Time Augmentation.
    
    Args:
        model: Trained model
        scaler: Fitted scaler
        X_test_raw: List of raw test sequences
        device: Device to run model on
        use_tta: Whether to use TTA (default False for consistency)
        tta_weight: Weight for TTA predictions (default 0.3 = 30% TTA, 70% original)
    
    Returns:
        Tuple of (dx_predictions, dy_predictions)
    """
    model.eval()
    outs_dx, outs_dy = [], []
    
    # Original prediction
    base = np.stack([scaler.transform(s) for s in X_test_raw]).astype(np.float32)
    xt = torch.tensor(base, device=device)

    with torch.no_grad():
        output = model(xt)
        dx = output[:, :, 0]
        dy = output[:, :, 1]

    outs_dx.append(dx.detach().cpu().numpy())
    outs_dy.append(dy.detach().cpu().numpy())
    
    # If TTA disabled, return averaged predictions (original pattern)
    if not use_tta:
        return np.mean(outs_dx, axis=0), np.mean(outs_dy, axis=0)
    
    # TTA: Apply augmentations and collect predictions
    # Using ONLY temporal_shift for 100% safety (no feature corruption)
    tta_augmentations = [
        ('temporal_shift', 1),      # Shift forward by 1 frame
        ('temporal_shift', -1),     # Shift backward by 1 frame
    ]
    
    for aug_idx, (aug_name, aug_param) in enumerate(tta_augmentations):
        # Apply augmentation to all sequences
        aug_seed = 42 + aug_idx  # Reproducible augmentations
        X_aug = [apply_tta_augmentation(seq, aug_name, aug_param, seed=aug_seed) 
                 for seq in X_test_raw]
        
        # Transform and predict
        base_aug = np.stack([scaler.transform(s) for s in X_aug]).astype(np.float32)
        xt_aug = torch.tensor(base_aug, device=device)
        
        with torch.no_grad():
            output_aug = model(xt_aug)
            dx_aug = output_aug[:, :, 0]
            dy_aug = output_aug[:, :, 1]
        
        outs_dx.append(dx_aug.detach().cpu().numpy())
        outs_dy.append(dy_aug.detach().cpu().numpy())
    
    # Average all predictions (1 original + 4 augmented)
    # Then apply TTA weight: blend original with TTA average
    mean_dx = np.mean(outs_dx, axis=0)
    mean_dy = np.mean(outs_dy, axis=0)
    
    # Weighted combination: more weight to original
    dx_orig = outs_dx[0]
    dy_orig = outs_dy[0]
    tta_dx = np.mean(outs_dx[1:], axis=0) if len(outs_dx) > 1 else dx_orig
    tta_dy = np.mean(outs_dy[1:], axis=0) if len(outs_dy) > 1 else dy_orig
    
    final_dx = (1 - tta_weight) * dx_orig + tta_weight * tta_dx
    final_dy = (1 - tta_weight) * dy_orig + tta_weight * tta_dy
    
    return final_dx, final_dy
