# LOFO/FLOFO Feature Importance Analysis

Scripts para analizar la importancia de features usando Leave-One-Feature-Out.

## 📋 Scripts Disponibles

### 1. **flofo_analysis.py** (RÁPIDO - 30 min)
- Usa modelos ya entrenados
- Permutación de features
- No re-entrena
- Ideal para iteración rápida

### 2. **lofo_group_analysis.py** (LENTO - 3-4 horas)
- Re-entrena sin cada grupo
- Más preciso
- Agrupa features relacionadas
- Mejor para decisiones finales

---

## 🚀 Uso en Kaggle

### Setup Inicial

```python
# En Kaggle Notebook, instalar dependencias
!pip install lofo-importance -q

# Subir tus archivos a Kaggle Dataset:
# - model_fold1.pt (modelo entrenado)
# - scaler_fold1.pkl (scaler)
# - Código src/ completo
```

### Opción 1: FLOFO (Rápido)

```python
# Copiar flofo_analysis.py a /kaggle/working/
# Editar paths en líneas 88-90:

MODEL_PATH = Path('/kaggle/input/tu-dataset/model_fold1.pt')
SCALER_PATH = Path('/kaggle/input/tu-dataset/scaler_fold1.pkl')

# Ejecutar
!python flofo_analysis.py
```

**Output:**
- `flofo_importance.csv` - Tabla de importancias
- `flofo_importance_plot.png` - Visualización

**Tiempo:** ~30 minutos

---

### Opción 2: LOFO por Grupos (Preciso)

```python
# Copiar lofo_group_analysis.py a /kaggle/working/

# Ejecutar
!python lofo_group_analysis.py

# NOTA: Toma 3-4 horas (entrena múltiples modelos)
```

**Output:**
- `lofo_group_importance.csv` - Importancia por grupo
- `lofo_group_importance_plot.png` - Visualización

**Tiempo:** ~3-4 horas

---

## 📊 Interpretación de Resultados

### FLOFO Importance

```
feature                 importance_mean  importance_std
distance_to_ball        +0.0145          0.0023
velocity_alignment      +0.0082          0.0015
lag10_x                 -0.0031          0.0008  ← ELIMINAR!
multi_window_roll20     -0.0012          0.0005  ← ELIMINAR!
```

**Leer:**
- `importance > 0` → Feature ayuda (mantener)
- `importance < 0` → Feature daña (eliminar)
- `std` alto → Feature inestable

---

### LOFO Group Importance

```
group               n_features  importance  rmse_without
neighbor_gnn        15          +0.0120     0.5976
target_alignment    10          +0.0095     0.5951
lag                 12          -0.0023     0.5833  ← Grupo daña!
```

**Leer:**
- `importance > 0` → Grupo importante
- `importance < 0` → Grupo daña performance
- `n_features` → Tamaño del grupo

---

## 🎯 Plan de Acción Recomendado

### Paso 1: FLOFO (rápido)
```bash
# 1. Correr FLOFO
python flofo_analysis.py

# 2. Identificar features dañinas (importance < -0.001)
# 3. Eliminar esas features de config.py
# 4. Re-entrenar modelo
```

**Ganancia esperada:** 0.003-0.008 yards

---

### Paso 2: LOFO (si tienes tiempo)
```bash
# 1. Correr LOFO por grupos
python lofo_group_analysis.py

# 2. Si un grupo completo tiene importance < 0:
#    → Desactivar en Config.FEATURE_GROUPS
# 3. Re-entrenar modelo completo
```

**Ganancia esperada:** 0.005-0.012 yards

---

### Paso 3: Refinamiento
```bash
# Basado en resultados:
# 1. Top 5 features → Crear variantes mejoradas
# 2. Features dañinas → Investigar por qué
# 3. Grupos inestables → Simplificar
```

---

## 📝 Ejemplo Completo en Kaggle Notebook

```python
# === Cell 1: Setup ===
!pip install lofo-importance -q

import sys
sys.path.append('/kaggle/working')

# === Cell 2: FLOFO Rápido ===
!python flofo_analysis.py

# === Cell 3: Ver Resultados ===
import pandas as pd
import matplotlib.pyplot as plt

results = pd.read_csv('flofo_importance.csv')
print("Top 10 Features:")
print(results.head(10))

print("\nHarmful Features:")
print(results[results['importance_mean'] < 0])

# === Cell 4: Visualizar ===
from IPM import Image
Image('flofo_importance_plot.png')

# === Cell 5: Decisiones ===
# Basado en resultados, actualizar config.py
# Ejemplo: Eliminar features con importance < -0.002
harmful = results[results['importance_mean'] < -0.002]['feature'].tolist()
print(f"Eliminar estas {len(harmful)} features:")
print(harmful)
```

---

## ⚠️ Consideraciones

### FLOFO
- ✅ **Rápido:** ~30 min
- ✅ **Iterativo:** Puedes correr múltiples veces
- ⚠️ **Aproximado:** Usa permutaciones, no re-entrenamiento
- ⚠️ **Correlation blind:** Puede subestimar features correlacionadas

### LOFO
- ✅ **Preciso:** Re-entrena realmente
- ✅ **Ground truth:** Mide impacto real
- ❌ **Lento:** 3-4 horas
- ❌ **Costoso:** Consume muchos recursos Kaggle

---

## 🔧 Troubleshooting

### Error: "Module not found"
```python
# Asegúrate de que src/ esté en path
import sys
sys.path.append('/kaggle/working')
sys.path.append('/kaggle/input/tu-codigo-dataset')
```

### Error: "Out of memory"
```python
# Reducir validation set en flofo_analysis.py línea 160
val_size = int(n_samples * 0.1)  # Usar 10% en vez de 20%
```

### Error: "Model load failed"
```python
# Verificar paths
print(f"Model exists: {MODEL_PATH.exists()}")
print(f"Scaler exists: {SCALER_PATH.exists()}")
```

---

## 📈 Ganancia Esperada Total

```
Baseline actual:            0.586 yards

Después de FLOFO:
- Eliminar 5-10 features dañinas: -0.005 yards

Después de LOFO:
- Optimizar grupos: -0.008 yards

Total mejora: 0.586 → 0.573 yards (-0.013)
```

---

## 💡 Tips

1. **Correr FLOFO primero** - Es rápido y da 80% del valor
2. **LOFO solo para decisiones finales** - Cuando ya refinaste con FLOFO
3. **Usar grupos lógicos** - Agrupa features relacionadas
4. **Iterar** - FLOFO → eliminar → re-entrenar → FLOFO again
5. **Documentar** - Guarda resultados de cada experimento

---

¡Buena suerte con el análisis! 🎯
