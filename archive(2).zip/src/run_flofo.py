"""
FLOFO (Fast Leave One Feature Out) Analysis - Local Execution
Analiza importancia de features usando modelos ya entrenados.

Uso:
    cd /home/dreuxx/Escritorio/550kaggle
    python -m src.run_flofo
"""

import numpy as np
import pandas as pd
import torch
import joblib
from pathlib import Path
from tqdm.auto import tqdm
import matplotlib.pyplot as plt
from sklearn.model_selection import GroupKFold

from src.config import Config
from src.model import STTransformer
from src.utils import load_input_output
from src.preprocess import prepare_sequences_with_advanced_features
from src.validation import compute_val_rmse_stt


class FLOFOImportance:
    """Fast LOFO using permutation importance."""
    
    def __init__(self, model, scaler, feature_names, device='cuda'):
        self.model = model
        self.scaler = scaler
        self.feature_names = feature_names
        self.device = device
        self.model.eval()
        
    def compute_importance(self, X_val, y_val_dx, y_val_dy, n_permutations=5):
        """Compute FLOFO importance for all features."""
        # Baseline performance
        X_val_scaled = [self.scaler.transform(x) for x in X_val]
        baseline_rmse = compute_val_rmse_stt(
            self.model,
            X_val_scaled,
            y_val_dx,
            y_val_dy,
            Config.MAX_FUTURE_HORIZON,
            self.device
        )
        
        print(f"  Baseline RMSE: {baseline_rmse:.4f} yards")
        
        # Feature importances
        importances = []
        
        for feat_idx in tqdm(range(len(self.feature_names)), desc="  FLOFO Progress"):
            feat_name = self.feature_names[feat_idx]
            
            # Permute this feature across samples
            permuted_rmses = []
            
            for _ in range(n_permutations):
                X_val_perm = []
                perm_indices = np.random.permutation(len(X_val))
                
                for i, x in enumerate(X_val):
                    x_perm = x.copy()
                    # Permute feature from random sample
                    donor_idx = perm_indices[i]
                    x_perm[:, feat_idx] = X_val[donor_idx][:, feat_idx]
                    X_val_perm.append(x_perm)
                
                # Scale and evaluate
                X_perm_scaled = [self.scaler.transform(x) for x in X_val_perm]
                rmse_perm = compute_val_rmse_stt(
                    self.model,
                    X_perm_scaled,
                    y_val_dx,
                    y_val_dy,
                    Config.MAX_FUTURE_HORIZON,
                    self.device
                )
                permuted_rmses.append(rmse_perm)
            
            # Importance = degradation when feature is permuted
            mean_rmse_perm = np.mean(permuted_rmses)
            std_rmse_perm = np.std(permuted_rmses)
            importance = mean_rmse_perm - baseline_rmse  # Positive = helpful
            
            importances.append({
                'feature': feat_name,
                'importance_mean': importance,
                'importance_std': std_rmse_perm,
                'baseline_rmse': baseline_rmse,
                'permuted_rmse_mean': mean_rmse_perm,
            })
        
        return pd.DataFrame(importances).sort_values('importance_mean', ascending=False)


def plot_importance(importance_df, top_n=30, output_path='flofo_importance_plot.png'):
    """Plot feature importance."""
    plt.figure(figsize=(12, 10))
    
    # Top N features
    top_df = importance_df.head(top_n)
    
    # Barplot
    y_pos = np.arange(len(top_df))
    colors = ['green' if x > 0 else 'red' for x in top_df['importance_mean']]
    
    plt.barh(y_pos, top_df['importance_mean'], 
             xerr=top_df['importance_std'], 
             capsize=3, 
             color=colors,
             alpha=0.7)
    
    plt.yticks(y_pos, top_df['feature'], fontsize=9)
    plt.xlabel('FLOFO Importance (yards)\n← Harmful (remove) | Helpful (keep) →', fontsize=11)
    plt.title(f'Top {top_n} Features by FLOFO Importance\n(Averaged across 5 folds)', fontsize=13, fontweight='bold')
    plt.axvline(x=0, color='black', linestyle='--', linewidth=1.5)
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"\n✓ Plot saved to {output_path}")
    
    return plt.gcf()


def main():
    """Main execution."""
    
    print("=" * 70)
    print("FLOFO IMPORTANCE ANALYSIS - NFL Big Data Bowl 2026")
    print("Using all 5 folds for robust estimates")
    print("=" * 70)
    
    # Paths
    MODEL_DIR = Config.SAVE_DIR / f"seed_{Config.SEEDS[0]}"
    
    # 1. Load models and scalers
    print("\n[1/5] Loading models and scalers from all 5 folds...")
    models = []
    scalers = []
    
    for fold in range(1, 6):
        model_path = MODEL_DIR / f"model_fold{fold}.pt"
        scaler_path = MODEL_DIR / f"scaler_fold{fold}.pkl"
        
        if not model_path.exists() or not scaler_path.exists():
            raise FileNotFoundError(f"Missing model/scaler for fold {fold} in {MODEL_DIR}")
        
        # Load scaler
        scaler = joblib.load(scaler_path)
        scalers.append(scaler)
        
        # Load model
        input_dim = scaler.n_features_in_
        model = STTransformer(input_dim=input_dim)
        model.load_state_dict(torch.load(model_path, map_location=Config.DEVICE))
        model.to(Config.DEVICE)
        model.eval()
        models.append(model)
    
    print(f"✓ Loaded {len(models)} models ({input_dim} features each)")
    
    # 2. Load data
    print("\n[2/5] Loading training data...")
    train_input, train_output = load_input_output()
    
    seqs, tdx, tdy, tfids, seq_meta, feat_cols = prepare_sequences_with_advanced_features(
        train_input,
        output_df=train_output,
        feature_groups=Config.FEATURE_GROUPS,
    )
    
    print(f"✓ Loaded {len(seqs)} samples with {len(feat_cols)} features")
    print(f"\nFeature groups active: {Config.FEATURE_GROUPS}")
    
    # 3. Create fold splits
    print("\n[3/5] Creating 5-fold splits...")
    
    # Match the training split logic (without augmentedoffset filtering)
    AUGMENTATION_OFFSET = int(1e9)
    groups = np.array([
        f"{d['game_id']}_{d['play_id'] % AUGMENTATION_OFFSET}" 
        for d in seq_meta
    ])
    unique_grps, groups_idx = np.unique(groups, return_inverse=True)
    
    gkf = GroupKFold(n_splits=5)
    fold_splits = list(gkf.split(seqs, y=None, groups=groups_idx))
    
    print(f"✓ Created 5 folds from {len(unique_grps)} unique groups")
    
    # 4. Run FLOFO on each fold
    print("\n[4/5] Running FLOFO Analysis...")
    all_fold_importances = []
    
    for fold_idx, (train_idx, val_idx) in enumerate(fold_splits, 1):
        print(f"\n{'='*60}\nFold {fold_idx}/5\n{'='*60}")
        
        # Filter augmented from validation (match training)
        is_augmented = [seq_meta[i]['play_id'] >= AUGMENTATION_OFFSET for i in range(len(seq_meta))]
        val_idx_filtered = [i for i in val_idx if not is_augmented[i]]
        
        print(f"Validation samples: {len(val_idx)} → {len(val_idx_filtered)} (filtered augmented)")
        
        # Get validation data
        X_val = [seqs[i] for i in val_idx_filtered]
        y_val_dx = [tdx[i] for i in val_idx_filtered]
        y_val_dy = [tdy[i] for i in val_idx_filtered]
        
        # Run FLOFO
        model = models[fold_idx - 1]
        scaler = scalers[fold_idx - 1]
        
        flofo = FLOFOImportance(model, scaler, feat_cols, device=Config.DEVICE)
        fold_df = flofo.compute_importance(X_val, y_val_dx, y_val_dy, n_permutations=5)
        
        fold_df['fold'] = fold_idx
        all_fold_importances.append(fold_df)
    
    # 5. Aggregate results
    print("\n" + "="*70)
    print("[5/5] Aggregating results across all folds...")
    print("="*70)
    
    combined_df = pd.concat(all_fold_importances, ignore_index=True)
    
    # Aggregate by feature
    importance_summary = combined_df.groupby('feature').agg({
        'importance_mean': ['mean', 'std'],
        'baseline_rmse': 'mean',
        'permuted_rmse_mean': 'mean',
    }).reset_index()
    
    importance_summary.columns = ['feature', 'importance_mean', 'importance_std', 
                                   'baseline_rmse', 'permuted_rmse_mean']
    
    importance_summary = importance_summary.sort_values('importance_mean', ascending=False)
    
    # Save results
    output_dir = Path('./output/flofo_analysis')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    importance_summary.to_csv(output_dir / 'flofo_importance_summary.csv', index=False)
    combined_df.to_csv(output_dir / 'flofo_importance_per_fold.csv', index=False)
    
    print(f"\n✓ Saved aggregated results to {output_dir / 'flofo_importance_summary.csv'}")
    print(f"✓ Saved per-fold details to {output_dir / 'flofo_importance_per_fold.csv'}")
    
    # Plot
    plot_importance(importance_summary, top_n=30, 
                   output_path=output_dir / 'flofo_importance_plot.png')
    
    # Print summary
    print("\n" + "="*70)
    print("FLOFO IMPORTANCE SUMMARY (Averaged across 5 folds)")
    print("="*70)
    
    print("\n🟢 Top 15 Most HELPFUL Features:")
    top_helpful = importance_summary.head(15)
    print(top_helpful[['feature', 'importance_mean', 'importance_std']].to_string(index=False))
    
    print("\n🔴 Top 15 Most HARMFUL Features (consider removing):")
    harmful = importance_summary[importance_summary['importance_mean'] < 0].head(15)
    if len(harmful) > 0:
        print(harmful[['feature', 'importance_mean', 'importance_std']].to_string(index=False))
        
        print(f"\n⚠️  Found {len(importance_summary[importance_summary['importance_mean'] < 0])} harmful features!")
        print("   Consider removing features with importance < -0.001")
    else:
        print("✓ No harmful features detected!")
    
    # Actionable insights
    print("\n" + "="*70)
    print("ACTIONABLE INSIGHTS")
    print("="*70)
    
    very_harmful = importance_summary[importance_summary['importance_mean'] < -0.002]
    if len(very_harmful) > 0:
        print(f"\n🚨 {len(very_harmful)} features significantly hurt performance (< -0.002 yards):")
        for _, row in very_harmful.iterrows():
            print(f"   - {row['feature']}: {row['importance_mean']:.4f} yards")
        
        print("\n💡 Recommended action: Remove these features from config.py")
        print("   Expected improvement: ~{:.3f} yards".format(-very_harmful['importance_mean'].sum()))
    
    print(f"\n📊 Mean baseline RMSE: {importance_summary['baseline_rmse'].iloc[0]:.4f} yards")
    print("="*70)


if __name__ == "__main__":
    main()
