import os
import torch
from pathlib import Path


def is_kaggle():
    return "KAGGLE_URL_BASE" in os.environ or "KAGGLE_KERNEL_RUN_TYPE" in os.environ


class Config:
    ############################################################
    #               Configuration (Mode & Path)                #
    ############################################################
    TIME_TAG = "default"

    # Status flag
    # Train in(==) local, submit in kaggle environment
    TRAIN = not is_kaggle()
    SUBMIT = not TRAIN

    # Debug mode: check pipeline integrity
    DEBUG = False
    DEBUG_SIZE = 1  # Number of weeks to load in debug mode
    
    PREFIX = "/kaggle/input/" if not TRAIN else ""
    DATA_DIR = Path(f"{PREFIX}nfl-big-data-bowl-2026-prediction/")
    OUTPUT_DIR = Path("./output")
    SAVE_DIR = Path(f"./output/{TIME_TAG}")

    # fallback to a single process in submit mode
    MAX_WORKER = min(8, os.cpu_count() or 1) if TRAIN else 1

    ############################################################
    #                    Feature Engineering                   #
    ############################################################

    # Specify the feature group
    # LOFO Analysis Results (Baseline: 0.5842 yards):
    # - passer: +0.0016 importance (HARMFUL - removed)
    # - geometric: +0.0006 importance (HARMFUL - removed)
    # - target_alignment: -0.0097 (CRITICAL)
    # - neighbor_gnn: -0.0079 (CRITICAL)
    # - basic: -0.0139 (CRITICAL)
    FEATURE_GROUPS = [
        "target_alignment",     # -0.0097 importance (CRITICAL)
        # "multi_window",
        "lag",                  # Part of basic features
        "motion_change",        # -0.0042 importance
        "field_position",       # -0.0026 importance
        "distance_rate",        # -0.0004 importance (marginal)
        # "geometric",          # +0.0006 importance (HARMFUL - REMOVED via LOFO)
        "neighbor_gnn",         # -0.0079 importance (CRITICAL)
        "time",                 # Part of other group
        # "role",
        # "passer",             # +0.0016 importance (HARMFUL - REMOVED via LOFO)
        "curvature",            # -0.0008 importance (marginal)
        "route",                # Part of other group
        "receiver",             # -0.0014 importance
        "relative_players",     # NEW: Relative features to receiver/defender
        "defense_aggregation",  # Aggregated defensive stats (7 features)
        "offense_aggregation",  # Aggregated offensive stats (5 features)
    ]

    # Neighbors feature
    K_NEIGH = 6
    RADIUS = 30.0
    TAU = 8.0

    ############################################################
    #                         Training                         #
    ############################################################

    # Training Setting
    #SEEDS = [42]
    SEEDS = [42, 19, 89, 64]
    N_FOLDS = 5
    BATCH_SIZE = 256
    EPOCHS = 350 if not DEBUG else 20
    PATIENCE = 30
    LEARNING_RATE = 1e-3
    
    # Test-Time Augmentation (TTA) - 100% Safe Implementation
    # Only temporal_shift (no feature corruption)
    # Only applied to best seed (seed 42) during inference for efficiency
    USE_TTA = True  # Enable TTA for seed 42 models
    TTA_WEIGHT = 0.3  # Weight for TTA (0.3 = 30% TTA, 70% original)

    # Fold-specific hyperparameters (optimized based on training results)
    # Avoid time_decay >= 0.04 (causes loss/RMSE mismatch)
    TIME_DECAYS = [0.03, 0.03, 0.034, 0.034, 0.03]
    WEIGHT_DECAYS = [5e-4, 1e-3, 1e-3, 1e-3, 1e-3]
    
    # Fold-specific MultiScaleLoss parameters  
    # Based on full training RMSE: [0.5737, 0.5860, 0.5607, 0.5961, 0.6113]
    # Fold 3 (best) gts lower weight, Folds 4-5 (worse) get higher weight
    FAR_WEIGHTS = [0.15, 0.15, 0.15, 0.15, 0.15]  # Per-fold far frame penalty
    FAR_THRESHOLDS = [35, 35, 35, 35, 35]         # Frame where "far" starts (uniform)

    WINDOW_SIZE = 10
    MAX_PLAYER = 9
    HIDDEN_DIM = 128
    MAX_FUTURE_HORIZON = 55  # Number of steps to predict (filter out 94)

    # AUGMENTATION
    USE_AUGMENTATION = True
    
    # Per-fold augmentation control (True = use augmentation, False = original only)
    # Set to None to use USE_AUGMENTATION for all folds
    USE_AUGMENTATION_PER_FOLD = [True, True, True, True, True]  # All folds enabled
    
    
    N_HEADS = 4
    N_LAYERS = 2
    MLP_HIDDEN_DIM = 256
    N_RES_BLOCKS = 2
    N_QUERYS = 1

    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Field Setting
    YARDS_TO_METERS = 0.9144
    FPS = 10.0

    FIELD_X_MIN, FIELD_X_MAX = 0.0, 120.0
    FIELD_Y_MIN, FIELD_Y_MAX = 0.0, 53.3
