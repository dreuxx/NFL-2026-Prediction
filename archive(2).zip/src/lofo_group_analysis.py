"""
LOFO (Leave One Feature Out) Group Analysis
Para ejecutar en Kaggle Notebooks

Este script re-entrena el modelo sin cada grupo de features
para medir su importancia real (más preciso pero más lento).

Uso:
    python lofo_group_analysis.py --data_path /kaggle/input/nfl-big-data-bowl-2026-prediction/
"""

import numpy as np
import pandas as pd
import torch
from pathlib import Path
from tqdm.auto import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler

import sys
sys.path.append('/kaggle/working')

from src.config import Config
from src.model import train_model_stt
from src.utils import load_input_output, prepare_targets_stt
from src.preprocess import prepare_sequences_with_advanced_features
from src.validation import compute_val_rmse_stt


# Define feature groups (based on Config.FEATURE_GROUPS)
# Each group maps to list of feature name patterns
FEATURE_GROUPS_MAP = {
    # Basic features (created in _create_basic_features)
    'basic': [
        'x', 'y', 's', 'a', 'dir', 'o', 'frame_id',
        'player_height_feet', 'height_inches', 'bmi',  
        'player_weight', 'speed_squared',
        'velocity_x', 'velocity_y',
        'acceleration_x', 'acceleration_y',
        'momentum_x', 'momentum_y', 'kinetic_energy',
        'orientation_diff', 'play_direction',
        'is_offense', 'is_defense', 'is_receiver', 'is_coverage', 'is_passer',
        'ball_land_x', 'ball_land_y',
    ],
    
    # Target alignment features
    'target_alignment': [
        'distance_to_ball', 'angle_to_ball', 'ball_direction_x', 'ball_direction_y',
        'angle_diff', 'closing_speed',
        'velocity_alignment', 'velocity_perpendicular',
        'accel_alignment', 'accel_perpendicular',
    ],
    
    # Lag features
    'lag': [
        '_lag1', '_lag2', '_lag3', '_lag5',  # Will match velocity_x_lag1, etc.
        '_diff_lag1', '_diff_lag2', '_diff_lag3',
    ],
    
    # Motion change features
    'motion_change': [
        'velocity_x_change', 'velocity_y_change',
        'speed_change', 'direction_change', 'o_change_rate',
    ],
    
    # Field position features  
    'field_position': [
        'dist_from_left', 'dist_from_right', 'dist_from_sideline',
        'dist_from_endzone', 'dist_from_center',
        'field_zone_x', 'field_zone_y',
        'in_red_zone', 'near_sideline',
    ],
    
    # Distance rate features
    'distance_rate': [
        'd2ball_dt', 'd2ball_ddt', 'd2ball_d3t',
        'time_to_intercept', 'closing_efficiency', 'intercept_urgency',
        'distance_ema3',
    ],
    
    # Geometric features
    'geometric': [
        'geo_endpoint_x', 'geo_endpoint_y',
        'rel_x', 'rel_y', 'rel_angle', 'rel_speed',
    ],
    
    # GNN/Neighbor features
    'neighbor_gnn': [
        'dx_ally_', 'dy_ally_', 's_ally_', 'dvx_ally_', 'dvy_ally_',
        'dx_opp_', 'dy_opp_', 's_opp_', 'dvx_opp_', 'dvy_opp_',
        'ally_pressure', 'opp_pressure',
        'local_density', 'avg_spacing',
    ],
    
    # Time features
    'time': [
        'frames_elapsed', 'time_since_snap',
    ],
    
    # Passer features
    'passer': [
        'passer_', 'to_passer_', 'from_passer_',
    ],
    
    # Curvature features
    'curvature': [
        'curvature', 'curvature_abs', 'curv_abs_roll',
        'bearing_to_land', 'land_lateral_offset', 'a_tangential',
    ],
    
    # Route features
    'route': [
        'route_depth', 'route_width', 'route_complexity',
        'route_angle', 'route_speed',
    ],
    
    # Receiver features
    'receiver': [
        'receiver_', 'to_receiver_', 'from_receiver_',
    ],
}


class LOFOGroupImportance:
    """
    Leave One Feature Group Out importance.
    Re-trains model without each feature group.
    """
    
    def __init__(self, feature_cols, feature_groups_map):
        self.feature_cols = feature_cols
        self.feature_groups_map = feature_groups_map
        
        # Build reverse mapping
        self.feature_to_group = {}
        for group_name, patterns in feature_groups_map.items():
            for feat in feature_cols:
                for pattern in patterns:
                    if feat.startswith(pattern) or feat == pattern:
                        self.feature_to_group[feat] = group_name
                        break
        
        # Group features by group
        self.grouped_features = {}
        for feat in feature_cols:
            group = self.feature_to_group.get(feat, 'other')
            if group not in self.grouped_features:
                self.grouped_features[group] = []
            self.grouped_features[group].append(feat)
    
    def get_features_without_group(self, group_name):
        """Return feature list without the specified group."""
        features_without = []
        for feat in self.feature_cols:
            if self.feature_to_group.get(feat, 'other') != group_name:
                features_without.append(feat)
        return features_without
    
    def compute_importance(self, sequences, targets_dx, targets_dy, groups_for_cv):
        """
        Compute LOFO importance for each feature group.
        """
        # Baseline: all features
        print("\n[BASELINE] Training with ALL features...")
        baseline_rmse = self._train_and_evaluate(
            sequences, targets_dx, targets_dy, groups_for_cv,
            use_features='all'
        )
        print(f"Baseline RMSE: {baseline_rmse:.4f} yards")
        
        # Test each group
        importances = []
        
        for group_name in tqdm(sorted(self.grouped_features.keys()), desc="Testing groups"):
            n_features = len(self.grouped_features[group_name])
            
            print(f"\n[{group_name}] Removing {n_features} features...")
            
            rmse_without = self._train_and_evaluate(
                sequences, targets_dx, targets_dy, groups_for_cv,
                use_features='all',
                exclude_group=group_name
            )
            
            # Importance = baseline - without (positive = group helps)
            importance = baseline_rmse - rmse_without
            
            importances.append({
                'group': group_name,
                'n_features': n_features,
                'importance': importance,
                'rmse_without': rmse_without,
                'baseline_rmse': baseline_rmse,
            })
            
            print(f"  RMSE without: {rmse_without:.4f} | Importance: {importance:+.4f}")
        
        return pd.DataFrame(importances).sort_values('importance', ascending=False)
    
    def _train_and_evaluate(self, sequences, targets_dx, targets_dy, groups_for_cv,
                           use_features='all', exclude_group=None):
        """Train model and return average validation RMSE."""
        
        # Determine which features to use
        if exclude_group:
            feature_indices = [i for i, feat in enumerate(self.feature_cols)
                              if self.feature_to_group.get(feat, 'other') != exclude_group]
        else:
            feature_indices = list(range(len(self.feature_cols)))
        
        # Filter sequences
        sequences_filtered = [seq[:, feature_indices] for seq in sequences]
        input_dim = len(feature_indices)
        
        # Cross-validation - USE ALL 5 FOLDS (same as production)
        gkf = GroupKFold(n_splits=5)
        fold_rmses = []
        
        for fold, (tr, va) in enumerate(gkf.split(sequences_filtered, groups=groups_for_cv), 1):
            X_tr = [sequences_filtered[i] for i in tr]
            X_va = [sequences_filtered[i] for i in va]
            y_tr_dx = [targets_dx[i] for i in tr]
            y_tr_dy = [targets_dy[i] for i in tr]
            y_va_dx = [targets_dx[i] for i in va]
            y_va_dy = [targets_dy[i] for i in va]
            
            # Scale
            scaler = StandardScaler()
            scaler.fit(np.vstack(X_tr))
            X_tr_sc = [scaler.transform(x) for x in X_tr]
            X_va_sc = [scaler.transform(x) for x in X_va]
            
            # Train with reduced epochs for Kaggle (but reasonable for convergence)
            Config.EPOCHS = 100  # Increased from 50 for better estimates
            Config.PATIENCE = 20
            
            model, _ = train_model_stt(
                X_tr_sc, y_tr_dx, y_tr_dy,
                X_va_sc, y_va_dx, y_va_dy,
                input_dim,
                time_decay=0.03,
                weight_decay=1e-5,
                far_weight=0.3,
                far_threshold=35
            )
            
            # Evaluate
            rmse = compute_val_rmse_stt(
                model, X_va_sc, y_va_dx, y_va_dy,
                Config.MAX_FUTURE_HORIZON,
                Config.DEVICE
            )
            
            fold_rmses.append(rmse)
        
        return np.mean(fold_rmses)


def plot_group_importance(importance_df, figsize=(10, 8)):
    """Plot group importance."""
    plt.figure(figsize=figsize)
    
    y_pos = np.arange(len(importance_df))
    colors = ['green' if x > 0 else 'red' for x in importance_df['importance']]
    
    plt.barh(y_pos, importance_df['importance'], color=colors, alpha=0.7)
    plt.yticks(y_pos, [f"{row['group']}\n({row['n_features']} feat)" 
                       for _, row in importance_df.iterrows()])
    plt.xlabel('LOFO Group Importance (yards)\n← Harmful | Helpful →')
    plt.title('Feature Group Importance (LOFO)')
    plt.axvline(x=0, color='black', linestyle='--', linewidth=1)
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    
    return plt.gcf()


def main():
    """Main execution."""
    
    print("=" * 70)
    print("LOFO Group Importance Analysis")
    print("=" * 70)
    
    # Load data
    print("\n[1/4] Loading data...")
    Config.DEBUG = False  # IMPORTANT: Use ALL data for reliable importance estimates
    # Config.DEBUG_SIZE not used when DEBUG=False
    
    train_input, train_output = load_input_output()
    
    seqs, tdx, tdy, tfids, seq_meta, feat_cols = prepare_sequences_with_advanced_features(
        train_input,
        output_df=train_output,
        feature_groups=Config.FEATURE_GROUPS,
    )
    
    # Create groups for CV
    groups = np.array([f"{m['game_id']}_{m['play_id']}" for m in seq_meta])
    _, groups_idx = np.unique(groups, return_inverse=True)
    
    print(f"✓ Loaded: {len(seqs)} sequences, {len(feat_cols)} features")
    
    # Run LOFO
    print("\n[2/4] Running LOFO Group Analysis...")
    lofo = LOFOGroupImportance(feat_cols, FEATURE_GROUPS_MAP)
    importance_df = lofo.compute_importance(seqs, tdx, tdy, groups_idx)
    
    # Save
    print("\n[3/4] Saving results...")
    importance_df.to_csv('lofo_group_importance.csv', index=False)
    print("✓ Saved to lofo_group_importance.csv")
    
    # Plot
    print("\n[4/4] Creating visualization...")
    fig = plot_group_importance(importance_df)
    fig.savefig('lofo_group_importance_plot.png', dpi=150, bbox_inches='tight')
    print("✓ Saved to lofo_group_importance_plot.png")
    
    # Summary
    print("\n" + "=" * 70)
    print("LOFO GROUP IMPORTANCE SUMMARY")
    print("=" * 70)
    print(importance_df.to_string(index=False))
    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
