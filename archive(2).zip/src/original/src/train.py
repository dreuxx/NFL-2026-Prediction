
from src.config import Config
from src.utils import (
    set_seed,
    load_input_output,
    write_meta,
    write_cv_log,
    load_saved_ensemble_stt,
)
from src.preprocess import prepare_sequences_with_advanced_features
from src.model import train_all_folds_stt
from src.predict import predict_sst

def train():
    # 1) load training data
    print("\n[1/4] Loading training data")
    train_input, train_output = load_input_output()

    # 2) features + sequences
    print("\n[2/4] Feature Engineering")
    feature_groups = Config.FEATURE_GROUPS
    seqs, tdx, tdy, tfids, seq_meta, feat_cols = (
        prepare_sequences_with_advanced_features(
            train_input,
            output_df=train_output,
            feature_groups=feature_groups,
        )
    )
    input_dim = seqs[0].shape[1]

    sequences = list(seqs)
    targets_dx = list(tdx)
    targets_dy = list(tdy)

    # write meta
    write_meta(feat_cols, base_dir=Config.SAVE_DIR)

    # 3) multi-seed × KFold, save per-fold artifacts
    print("\n[3/4] Training model...")
    groups = np.array([f"{d['game_id']}_{d['play_id']}" for d in seq_meta])
    unique_grps, groups = np.unique(groups, return_inverse=True)
    print(f"Created {len(unique_grps)} unique groups (game_play_id) for GroupKFold.")

    seeds = Config.SEEDS
    all_rmse = []
    cv_log = []

    for seed in seeds:
        print(f"\n{'='*70}\n   Seed {seed}\n{'='*70}")
        set_seed(seed)
        gkf = GroupKFold(n_splits=Config.N_FOLDS)

        _all_rmse, _cv_log = train_all_folds_stt(
            gkf, sequences, groups, targets_dx, targets_dy, seed, input_dim
        )

        all_rmse.extend(_all_rmse)
        cv_log.extend(_cv_log)

    print()
    print(f"[CV SUMMARY] all folds RMSEs: {[f'{r:.4f}' for r in all_rmse]}")
    print(f"[CV SUMMARY] overall mean RMSE = {float(np.mean(all_rmse)):.4f} yards")

    write_cv_log(cv_log, all_rmse)
    return


if __name__ == "__main__":
    if Config.TRAIN:
        train()

